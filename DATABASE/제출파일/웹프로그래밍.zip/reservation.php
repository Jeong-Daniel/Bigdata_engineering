<?
	$conn=mysqli_connect("localhost", "", "", "") or die("movieDB 접속 실패 !!");
	
	$movie_id = $_GET['movie_id'];

	$sql	= "select * from MOVIE where id = '".$movie_id."'";
	//echo $sql;
	//exit;  //일시 멈춤, 디버깅할때 유용한 명령어

	$result	= mysqli_query($conn, $sql);
	$row	= mysqli_fetch_array($result);
	$title	= $row['title']; // * 모든 필드에서 title 필드 가져오기 의미
	
	mysqli_close($conn);
?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="initial-scale=1.0, width=device-width">
	<title>예약하기</title>
     <!-- 제이쿼리 모바일, 제이쿼리 라이브러리 화일 -->
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css"/>
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>	
</head>  
<body>
  <div data-role="page" id="id">
	<div data-role="content">
		<form name="form1" method="post" enctype="multipart/form-data" action="reservation_result.php" data-ajax="false">  
			<h3>영화제목: <?=$title?><br><br>
			영화번호
				<input type="text" name="movie_id" value="<?=$movie_id?>" data-mini="true">
				예약자
				<input type="text" name="r_name" value="" data-mini="true">
				예약일
				<input type="date" name="r_date" value="" data-mini="true">
				예약인원
				<input type="text" name="r_count" value="" data-mini="true">
		</form>
			<div class="ui-body">
				<fieldset class="ui-grid-a">
					<div class="ui-block-a"><input type="reset" value="취소"/></div>
					<div class="ui-block-b"><input type="submit" value="예약"/></div>
				</fieldset>
			</div>
	</div>
  </div>
</body>	