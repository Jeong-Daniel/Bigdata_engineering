<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
<?
	$conn=mysqli_connect("localhost", "", "", "") or die("movieDB 접속 실패 !!");
	
	$movie_id = $_POST["movie_id"];
    $r_name = $_POST["r_name"];
    $r_date = $_POST["r_date"];
    $r_count = $_POST["r_count"];

	$sql	= "select * from MOVIE where id = '".$movie_id."'";

	$result	= mysqli_query($conn, $sql);
	$row	= mysqli_fetch_array($result);
	$title	= $row['title'];

	$sql="INSERT INTO reservation(movie_id, r_name, r_date, r_count) VALUES('".$movie_id."','".$r_name."','".$r_date."','".$r_count."');";     
	$result=mysqli_query($conn, $sql);

	if($result) {
            echo "<script>alert('".$title." 예약이 완료되었습니다.');</script>"; 
        }
    else {
            $err_msg=mysqli_error($conn);
            echo "<script>alert(\"SQL문 정보추가 오류입니다. \\n오류내용: $err_msg\");</script>" ;
		}   
		
	mysqli_close($conn);
	echo '<script>location.replace("main.php");</script>'; 
?>
</body>
</html>